package app.isle.phone

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.IntentCompat
import java.util.concurrent.atomic.AtomicInteger

/** Пункт «Отправить на ПК» в меню «Поделиться»: текст, ссылки, фото и файлы уходят на остров. */
class ShareActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!Prefs.paired(this)) {
            Toast.makeText(this, "Сначала подключите ПК в приложении Isle", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        val uris = ArrayList<Uri>()
        var text: String? = null
        when (intent.action) {
            Intent.ACTION_SEND -> {
                text = intent.getStringExtra(Intent.EXTRA_TEXT)
                val one = IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
                if (one != null) uris.add(one)
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val many = IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
                if (many != null) uris.addAll(many)
            }
        }

        val jobs = uris.size + (if (!text.isNullOrBlank()) 1 else 0)
        if (jobs == 0) {
            Toast.makeText(this, "Нечего отправлять", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        Toast.makeText(this, "Отправляю на ПК…", Toast.LENGTH_SHORT).show()

        val left = AtomicInteger(jobs)
        val failed = AtomicInteger(0)
        val finishOne = { ok: Boolean ->
            if (!ok) failed.incrementAndGet()
            if (left.decrementAndGet() == 0) {
                runOnUiThread {
                    val msg = if (failed.get() == 0) "Отправлено на ПК" else "Не удалось отправить: ${failed.get()}. ПК включён и в той же сети?"
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                    finish()
                }
            }
        }

        if (!text.isNullOrBlank()) Net.postText(this, text, finishOne)
        for (u in uris) Net.postFile(this, u, finishOne)
    }
}
