package app.isle.phone

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat

/** Кнопка «Скачать» в уведомлении о файле с ПК. Файл попадает в Загрузки/Isle. */
class ActionReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_DOWNLOAD = "app.isle.phone.DOWNLOAD"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_DOWNLOAD) return
        val url = intent.getStringExtra("url") ?: return
        val name = (intent.getStringExtra("name") ?: "file").replace(Regex("[\\\\/:*?\"<>|]"), "_")
        try {
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle(name)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Isle/$name")
            context.getSystemService(Context.DOWNLOAD_SERVICE).let { (it as DownloadManager).enqueue(req) }
            Toast.makeText(context, "Скачиваю: $name", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Не удалось скачать файл", Toast.LENGTH_LONG).show()
        }
        NotificationManagerCompat.from(context).cancel(intent.getIntExtra("nid", -1))
    }
}
