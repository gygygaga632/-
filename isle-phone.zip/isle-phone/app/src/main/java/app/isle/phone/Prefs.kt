package app.isle.phone

import android.content.Context
import android.content.SharedPreferences
import java.net.URI

/** Всё, что приложение помнит: адрес ПК, ключ, настройки пересылки уведомлений. */
object Prefs {
    private fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("isle", Context.MODE_PRIVATE)

    fun base(c: Context): String? = sp(c).getString("base", null)
    fun key(c: Context): String? = sp(c).getString("key", null)
    fun paired(c: Context): Boolean = base(c) != null && key(c) != null

    /** Принимает ссылку из QR-кода острова: http://192.168.1.15:47615/?k=0123456789abcdef */
    fun savePairing(c: Context, link: String): Boolean {
        try {
            val uri = URI(link.trim())
            val host = uri.host ?: return false
            if (uri.scheme != "http") return false
            val query = uri.rawQuery ?: return false
            var k: String? = null
            for (part in query.split("&")) {
                val kv = part.split("=", limit = 2)
                if (kv.size == 2 && kv[0] == "k") k = kv[1]
            }
            if (k == null || !Regex("[a-f0-9]{16}").matches(k)) return false
            val port = if (uri.port > 0) uri.port else 80
            sp(c).edit()
                .putString("base", "http://$host:$port")
                .putString("key", k)
                .apply()
            return true
        } catch (e: Exception) {
            return false
        }
    }

    fun forget(c: Context) {
        sp(c).edit().remove("base").remove("key").apply()
    }

    /** Пересылать ли уведомления телефона на ПК. */
    fun mirror(c: Context): Boolean = sp(c).getBoolean("mirror", true)
    fun setMirror(c: Context, on: Boolean) {
        sp(c).edit().putBoolean("mirror", on).apply()
    }

    /** Приложения, уведомления которых не пересылаются. */
    fun blocked(c: Context): Set<String> =
        HashSet(sp(c).getStringSet("blocked", emptySet()) ?: emptySet())

    fun setBlocked(c: Context, pkg: String, blocked: Boolean) {
        val set = HashSet(blocked(c))
        if (blocked) set.add(pkg) else set.remove(pkg)
        sp(c).edit().putStringSet("blocked", set).apply()
    }
}
