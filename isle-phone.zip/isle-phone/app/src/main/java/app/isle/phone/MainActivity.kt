package app.isle.phone

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

class MainActivity : AppCompatActivity() {

    private lateinit var statusView: TextView
    private lateinit var accessView: TextView
    private lateinit var linkInput: EditText
    private lateinit var mirrorSwitch: SwitchCompat
    private val handler = Handler(Looper.getMainLooper())

    private val scan = registerForActivityResult(ScanContract()) { result ->
        val text = result.contents
        if (text != null) pair(text)
    }

    private val askNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    private fun label(text: String, sp: Float, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sp
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        return t
    }

    private fun button(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun gap(root: LinearLayout, h: Int) {
        root.addView(View(this), LinearLayout.LayoutParams(1, dp(h)))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Isle"

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(24), dp(20), dp(24))

        root.addView(label("Isle", 28f, true))
        gap(root, 4)
        root.addView(label("Связь телефона с островом на ПК", 15f))
        gap(root, 20)

        // --- подключение ---
        root.addView(label("Подключение", 13f, true))
        statusView = label("", 16f)
        statusView.setPadding(0, dp(6), 0, dp(10))
        root.addView(statusView)
        root.addView(button("Сканировать QR-код") {
            scan.launch(
                ScanOptions()
                    .setPrompt("Наведите на QR-код во вкладке «Телефон» острова")
                    .setBeepEnabled(false)
                    .setOrientationLocked(false)
                    .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            )
        })
        linkInput = EditText(this)
        linkInput.hint = "или вставьте ссылку из острова"
        linkInput.setSingleLine(true)
        root.addView(linkInput)
        root.addView(button("Подключить по ссылке") {
            val v = linkInput.text.toString()
            if (v.isNotBlank()) pair(v)
        })
        root.addView(button("Отключиться от ПК") {
            ConnectionService.stop(this)
            Prefs.forget(this)
            refresh()
        })
        gap(root, 24)

        // --- уведомления ---
        root.addView(label("Уведомления на остров", 13f, true))
        accessView = label("", 15f)
        accessView.setPadding(0, dp(6), 0, dp(10))
        root.addView(accessView)
        root.addView(button("Открыть доступ к уведомлениям") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        mirrorSwitch = SwitchCompat(this)
        mirrorSwitch.text = "Пересылать уведомления на ПК"
        mirrorSwitch.isChecked = Prefs.mirror(this)
        mirrorSwitch.setOnCheckedChangeListener { _, on -> Prefs.setMirror(this, on) }
        mirrorSwitch.setPadding(0, dp(10), 0, dp(10))
        root.addView(mirrorSwitch)
        root.addView(button("Выбрать приложения") {
            startActivity(Intent(this, AppsActivity::class.java))
        })
        root.addView(label("Текст уведомлений уходит только на ваш ПК по домашней сети.", 12f))
        gap(root, 24)

        // --- работа в фоне ---
        root.addView(label("Работа в фоне", 13f, true))
        gap(root, 6)
        root.addView(button("Не ограничивать батареей") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        root.addView(label("Найдите Isle в списке и выберите «Не оптимизировать». Тогда связь не обрывается, когда экран выключен.", 12f))
        gap(root, 24)

        root.addView(label("Отправка на ПК: в любом приложении нажмите «Поделиться» и выберите «Отправить на ПК (Isle)».", 13f))

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Prefs.paired(this)) ConnectionService.start(this)
    }

    private fun pair(link: String) {
        if (Prefs.savePairing(this, link)) {
            Toast.makeText(this, "ПК подключён", Toast.LENGTH_SHORT).show()
            linkInput.setText("")
            ConnectionService.start(this)
        } else {
            Toast.makeText(this, "Это не ссылка из острова Isle", Toast.LENGTH_LONG).show()
        }
        refresh()
    }

    private fun refresh() {
        val base = Prefs.base(this)
        statusView.text = if (base != null) {
            base.removePrefix("http://") + "\n" + ConnectionService.status
        } else {
            "Не подключено. Откройте вкладку «Телефон» в острове и отсканируйте QR-код."
        }
        val granted = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        accessView.text = if (granted) {
            "Доступ к уведомлениям выдан."
        } else {
            "Доступ не выдан. На Android 13 и новее сначала откройте «Сведения о приложении Isle», в меню ⋮ выберите «Разрешить ограниченные настройки», затем выдайте доступ."
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    @Suppress("unused")
    private fun openAppInfo() {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )
    }
}
