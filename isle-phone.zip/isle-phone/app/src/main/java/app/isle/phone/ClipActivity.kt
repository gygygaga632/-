package app.isle.phone

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast

/** Невидимый экран: копирует присланный текст в буфер (Android разрешает это только на переднем плане). */
class ClipActivity : Activity() {
    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !done) {
            done = true
            val text = intent.getStringExtra("text") ?: ""
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Isle", text))
            Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
