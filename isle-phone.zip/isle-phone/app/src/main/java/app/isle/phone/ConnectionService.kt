package app.isle.phone

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection

/** Держит связь с островом на ПК и показывает то, что прислал компьютер. */
class ConnectionService : Service() {

    companion object {
        const val CH_CONN = "conn"
        const val CH_IN = "incoming"
        private const val ONGOING_ID = 1

        @Volatile
        var status: String = "Не подключено"

        fun start(c: Context) {
            try {
                ContextCompat.startForegroundService(c, Intent(c, ConnectionService::class.java))
            } catch (e: Exception) {
                // Система может запретить запуск из фона. Приложение попробует снова при открытии.
            }
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, ConnectionService::class.java))
            status = "Не подключено"
        }
    }

    @Volatile
    private var running = false
    private var worker: Thread? = null
    private var counter = 100

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_CONN, "Связь с ПК", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_IN, "Присланное с ПК", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = ongoing("Подключаюсь…")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ONGOING_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ONGOING_ID, n)
        }
        if (!Prefs.paired(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (worker?.isAlive != true) {
            running = true
            worker = Thread { loop() }.also { it.start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        super.onDestroy()
    }

    private fun ongoing(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CH_CONN)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Isle")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun setStatus(text: String) {
        status = text
        try {
            getSystemService(NotificationManager::class.java).notify(ONGOING_ID, ongoing(text))
        } catch (e: Exception) {
            // уведомление не обязательно для работы связи
        }
    }

    private fun loop() {
        var delay = 1000L
        while (running) {
            try {
                val u = Net.url(this, "/api/events") ?: break
                val conn = u.openConnection() as HttpURLConnection
                conn.connectTimeout = 5000
                conn.readTimeout = 45000
                conn.setRequestProperty("Accept", "text/event-stream")
                val code = conn.responseCode
                if (code == 403) {
                    setStatus("Ключ не подходит. Подключитесь заново")
                    Prefs.forget(this)
                    running = false
                    stopSelf()
                    return
                }
                if (code != 200) throw java.io.IOException("HTTP $code")
                setStatus("Связь с ПК есть")
                delay = 1000L
                BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { r ->
                    var ev = ""
                    var data = ""
                    while (running) {
                        val line = r.readLine() ?: break
                        if (line.startsWith("event:")) {
                            ev = line.substring(6).trim()
                        } else if (line.startsWith("data:")) {
                            data += line.substring(5).trim()
                        } else if (line.isEmpty()) {
                            if (ev.isNotEmpty()) handle(ev, data)
                            ev = ""
                            data = ""
                        }
                    }
                }
                conn.disconnect()
            } catch (e: InterruptedException) {
                return
            } catch (e: Exception) {
                // нет сети или ПК выключен: ждём и пробуем снова
            }
            if (!running) return
            setStatus("Нет связи, переподключаюсь…")
            try {
                Thread.sleep(delay)
            } catch (e: InterruptedException) {
                return
            }
            delay = minOf(delay * 2, 15000L)
        }
    }

    private fun handle(event: String, data: String) {
        try {
            val j = JSONObject(data)
            when (event) {
                "text" -> showText(j.getString("text"))
                "file" -> showFile(j.getString("id"), j.getString("name"), j.optLong("size", 0))
            }
        } catch (e: Exception) {
            // непонятное событие пропускаем
        }
    }

    private fun showText(text: String) {
        val id = counter++
        val copy = PendingIntent.getActivity(
            this, id,
            Intent(this, ClipActivity::class.java)
                .putExtra("text", text)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CH_IN)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Текст с ПК")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(copy)
            .addAction(0, "Копировать", copy)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        notifySafe(id, n)
    }

    private fun showFile(fileId: String, name: String, size: Long) {
        val id = counter++
        val link = Net.url(this, "/api/dl/$fileId")?.toString() ?: return
        val dl = PendingIntent.getBroadcast(
            this, id,
            Intent(this, ActionReceiver::class.java)
                .setAction(ActionReceiver.ACTION_DOWNLOAD)
                .putExtra("url", link)
                .putExtra("name", name)
                .putExtra("nid", id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val kb = if (size > 1048576) "%.1f МБ".format(size / 1048576.0) else "${maxOf(1L, size / 1024)} КБ"
        val n = NotificationCompat.Builder(this, CH_IN)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Файл с ПК")
            .setContentText("$name · $kb")
            .setContentIntent(dl)
            .addAction(0, "Скачать", dl)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        notifySafe(id, n)
    }

    private fun notifySafe(id: Int, n: Notification) {
        try {
            getSystemService(NotificationManager::class.java).notify(id, n)
        } catch (e: SecurityException) {
            // нет разрешения на уведомления
        }
    }
}
