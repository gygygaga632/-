package app.isle.phone

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Запросы к серверу на ПК (HTTP по локальной сети, доступ по ключу из QR-кода). */
object Net {
    private val pool: ExecutorService = Executors.newFixedThreadPool(2)

    fun url(c: Context, path: String): URL? {
        val base = Prefs.base(c) ?: return null
        val key = Prefs.key(c) ?: return null
        val sep = if (path.contains("?")) "&" else "?"
        return URL(base + path + sep + "k=" + key)
    }

    fun postJson(c: Context, path: String, json: JSONObject, done: ((Boolean) -> Unit)? = null) {
        val app = c.applicationContext
        pool.execute {
            var ok = false
            try {
                val u = url(app, path) ?: throw IOException("нет подключения")
                val conn = u.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 5000
                conn.readTimeout = 10000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                conn.outputStream.use { it.write(json.toString().toByteArray(Charsets.UTF_8)) }
                ok = conn.responseCode == 200
                conn.disconnect()
            } catch (e: Exception) {
                ok = false
            }
            done?.invoke(ok)
        }
    }

    fun postText(c: Context, text: String, done: ((Boolean) -> Unit)? = null) {
        postJson(c, "/api/text", JSONObject().put("text", text), done)
    }

    fun postFile(c: Context, uri: Uri, done: (Boolean) -> Unit) {
        val app = c.applicationContext
        pool.execute {
            var ok = false
            try {
                val cr = app.contentResolver
                var name = "file"
                var size = -1L
                cr.query(uri, null, null, null, null)?.use { cur ->
                    if (cur.moveToFirst()) {
                        val ni = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (ni >= 0) name = cur.getString(ni) ?: name
                        val si = cur.getColumnIndex(OpenableColumns.SIZE)
                        if (si >= 0 && !cur.isNull(si)) size = cur.getLong(si)
                    }
                }
                val u = url(app, "/api/file") ?: throw IOException("нет подключения")
                val conn = u.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.connectTimeout = 5000
                conn.readTimeout = 120000
                if (size >= 0) conn.setFixedLengthStreamingMode(size) else conn.setChunkedStreamingMode(64 * 1024)
                conn.setRequestProperty("X-Name", URLEncoder.encode(name, "UTF-8").replace("+", "%20"))
                val input = cr.openInputStream(uri) ?: throw IOException("не удалось открыть файл")
                input.use { inp ->
                    conn.outputStream.use { out -> inp.copyTo(out, 64 * 1024) }
                }
                ok = conn.responseCode == 200
                conn.disconnect()
            } catch (e: Exception) {
                ok = false
            }
            done(ok)
        }
    }
}
