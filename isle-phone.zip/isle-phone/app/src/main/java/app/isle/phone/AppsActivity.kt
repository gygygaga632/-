package app.isle.phone

import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

/** Список приложений: что включено, то и пересылается на остров. */
class AppsActivity : AppCompatActivity() {

    private class Row(val pkg: String, val label: String, val icon: Drawable)

    private val rows = ArrayList<Row>()
    private lateinit var blocked: HashSet<String>

    private fun dp(n: Int): Int = (n * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Какие приложения пересылать"
        blocked = HashSet(Prefs.blocked(this))

        val list = ListView(this)
        setContentView(list)
        list.adapter = adapter

        Thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val found = ArrayList<Row>()
            for (ri in pm.queryIntentActivities(intent, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName) continue
                found.add(Row(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm)))
            }
            found.sortBy { it.label.lowercase() }
            runOnUiThread {
                rows.clear()
                rows.addAll(found)
                adapter.notifyDataSetChanged()
            }
        }.start()
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount(): Int = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val r = rows[position]
            val line = LinearLayout(this@AppsActivity)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL
            line.setPadding(dp(16), dp(8), dp(16), dp(8))

            val icon = ImageView(this@AppsActivity)
            icon.setImageDrawable(r.icon)
            line.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))

            val name = TextView(this@AppsActivity)
            name.text = r.label
            name.textSize = 16f
            name.setPadding(dp(14), 0, dp(8), 0)
            line.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val sw = SwitchCompat(this@AppsActivity)
            sw.isChecked = !blocked.contains(r.pkg)
            sw.setOnCheckedChangeListener { _, on ->
                if (on) blocked.remove(r.pkg) else blocked.add(r.pkg)
                Prefs.setBlocked(this@AppsActivity, r.pkg, !on)
            }
            line.addView(sw)
            return line
        }
    }
}
