package app.isle.phone

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject

/** Пересылает уведомления телефона на остров. Нужен доступ к уведомлениям в настройках Android. */
class NotifListener : NotificationListenerService() {

    private val recent = HashMap<String, Long>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs.paired(this) || !Prefs.mirror(this)) return
        val pkg = sbn.packageName
        if (pkg == packageName) return
        if (Prefs.blocked(this).contains(pkg)) return

        val n = sbn.notification
        val skip = Notification.FLAG_ONGOING_EVENT or
            Notification.FLAG_GROUP_SUMMARY or
            Notification.FLAG_FOREGROUND_SERVICE
        if ((n.flags and skip) != 0) return

        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return

        // Мессенджеры обновляют одно и то же уведомление несколько раз подряд
        val sig = "$pkg|$title|$text"
        val now = System.currentTimeMillis()
        val last = recent[sig]
        if (last != null && now - last < 3000) return
        recent[sig] = now
        if (recent.size > 50) recent.entries.removeIf { now - it.value > 10000 }

        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        Net.postJson(
            this, "/api/notify",
            JSONObject().put("app", label).put("pkg", pkg).put("title", title).put("text", text)
        )
    }
}
